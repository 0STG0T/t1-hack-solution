from .document_processor import DocumentProcessor, document_processor

__all__ = ['DocumentProcessor', 'document_processor']
