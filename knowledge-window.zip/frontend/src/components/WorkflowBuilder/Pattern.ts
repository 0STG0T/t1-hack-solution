export enum Pattern {
  Dots = 'dots',
  Lines = 'lines',
  Cross = 'cross'
}
